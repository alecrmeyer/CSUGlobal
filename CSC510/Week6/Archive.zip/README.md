Instructions to execute:

1. Ensure that you have the following python packages installed:
    numpy
    pandas
    matplotlib
    scikit-learn

2. Execute the the python script with the following command:
    python Critical_Thinking_6.py

3. View the Matplotlib output